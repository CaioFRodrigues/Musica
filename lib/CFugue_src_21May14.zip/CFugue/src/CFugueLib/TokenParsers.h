#ifndef __TOKENPARSERS_H__D8FF9EC8_8F24_45ae_A9E5_E93DDD5684B2__
#define __TOKENPARSERS_H__D8FF9EC8_8F24_45ae_A9E5_E93DDD5684B2__

#include "MusicStringParser.h"

namespace CFugue
{
	//void ReadVoice(const MusicString& ) { }
	//void ReadTempo(const MusicString& ) { }
	//void ReadInstrument(const MusicString& ) { }
	//void ReadLayer(const MusicString& ) { }
	//void ReadKeySignature(const MusicString& ) { }
	//void ReadController(const MusicString& ) { }
	//void ReadTime(const MusicString& ) { }
	//void ReadKeyPressure(const MusicString& ) { }
	//void ReadChannelPressure(const MusicString& ) { }
	//void ReadPitchBend(const MusicString& ) { }
	//void ReadMeasure(const MusicString& ) { }
	//void ReadDictionary(const MusicString& ) { }
	//void ReadNote(const MusicString& ) { }

	namespace Western
	{
		//const MusicStringParser::TokenClassifierDef TokenClassifiers[] =
		//{
		//	_T('V')/*, ReadVoice,*/
		//	//_T('T'), ReadTempo,
		//	//_T('I'), ReadInstrument,
		//	//_T('L'), ReadLayer,
		//	//_T('K'), ReadKeySignature,
		//	//_T('X'), ReadController,
		//	//_T('@'), ReadTime,
		//	//_T('*'), ReadKeyPressure,
		//	//_T('+'), ReadChannelPressure,
		//	//_T('&'), ReadPitchBend,
		//	//_T('|'), ReadMeasure,
		//	//_T('$'), ReadDictionary,
		//	//_T('A'), ReadNote,
		//	//_T('B'), ReadNote,
		//	//_T('C'), ReadNote,
		//	//_T('D'), ReadNote,
		//	//_T('E'), ReadNote,
		//	//_T('F'), ReadNote,
		//	//_T('G'), ReadNote,
		//	//_T('R'), ReadNote,
		//	//_T('['), ReadNote,

		//}; // TokenClassifiers

	} // namespace Western

} // namespace CFugue

#endif //__TOKENPARSERS_H__D8FF9EC8_8F24_45ae_A9E5_E93DDD5684B2__