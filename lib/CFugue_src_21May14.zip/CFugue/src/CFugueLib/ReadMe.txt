CFugue Library
