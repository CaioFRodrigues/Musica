#include "stdafx.h"
#include "TokenParsers.h"

namespace CFugue
{


} // namespace CFugue