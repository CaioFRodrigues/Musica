/*
	This is part of CFugue, a C++ Runtime for MIDI Score Programming
	Copyright (C) 2009 Gopalakrishna Palem

	For links to further information, or to contact the author,
	see <http://cfugue.sourceforge.net/>.
    
    $LastChangedDate: 2013-12-18 10:59:57 +0530 (Wed, 18 Dec 2013) $
    $Rev: 197 $
    $LastChangedBy: krishnapg $
*/

#ifndef __VOICE_H__4FBD8E09_755B_4f7f_B129_B22444EA8813__
#define __VOICE_H__4FBD8E09_755B_4f7f_B129_B22444EA8813__

namespace CFugue
{
    /// <Summary>
    /// Class that represents Voice changes, also known as <i>track</i> changes
    /// </Summary>
    class Voice
    {
        unsigned char m_nTrack;
    public:
        inline Voice(unsigned char nTrackID) : m_nTrack(nTrackID) { }
        /// Returns the Voice represented by this object
        inline unsigned char GetVoice() const { return m_nTrack; }
    };

} // namespace CFugue

#endif // __VOICE_H__4FBD8E09_755B_4f7f_B129_B22444EA8813__